package com.custodian_service.custodianService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustodianServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
