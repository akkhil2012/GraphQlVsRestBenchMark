package com.custodian_service.custodianService.dag;

import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.ollama.api.OllamaOptions;

import java.util.ArrayList;
import java.util.List;

public class DocumentRetriever {
    private List<String> documents;

    public DocumentRetriever() {
        this.documents = new ArrayList<>();
        // Load your documents or data source here
        documents.add("How to reset your password: Go to login, click 'Forgot Password?', follow instructions.");
        documents.add("To update your email, visit your account settings.");
        documents.add("Contact support at support@example.com for further assistance.");
    }

    /*public List<String> retrieveDocuments(String query) {
        ChatResponse response = chatModel.call(
                new Prompt(
                        query,
                        OllamaOptions.create()
                                .withModel("llama3")
                                .withTemperature(0.4f)
                ));
        return response.getResult().getOutput().getContent();
    }*/
}
