package com.custodian_service.custodianService.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

@Table(name="project")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    // add custodianas to Project
    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL, orphanRemoval = true)
    List<Custodian> custodianList;// = new ArrayList<>();


    public Project(String name, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.name = name;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    private String name;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public void addCustodian(Custodian custodian) {
        custodianList.add(custodian);
        custodian.setProject(this);// setting the reverse relationship
    }
}
