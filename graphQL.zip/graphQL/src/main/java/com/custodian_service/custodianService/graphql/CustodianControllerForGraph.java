package com.custodian_service.custodianService.graphql;

import com.custodian_service.custodianService.model.Custodian;
import com.custodian_service.custodianService.model.Project;
import com.custodian_service.custodianService.service.CustodianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class CustodianControllerForGraph {

    @Autowired
    private CustodianService custodianService;

    // for graphQL
    @QueryMapping
    public List<Custodian> getCustodians(){
        return custodianService.findAllCustodians();
    }

    @MutationMapping
    public ResponseEntity<Custodian> updateCustodian(@Argument Long id, @Argument String name){
        Custodian cust =  custodianService.updateCustodian(id,name);
        return ResponseEntity.ok(cust);
    }

    @MutationMapping
    public Custodian deleteCustodian(@Argument Long id,@Argument String name){
        return custodianService.updateCustodian(id,name);
    }

    @MutationMapping
    public Custodian mergeCustodian(@Argument Long primary,@Argument Long duplicate){
        return custodianService.mergeCustodian(52l,54l);
    }

    // for project
    @MutationMapping
    public Project assignCustodians(@Argument List<Custodian> custodians, @Argument Project project){
        return custodianService.assignCustodians(custodians,project);
    }


}
