package com.custodian_service.custodianService.service;

import com.custodian_service.custodianService.model.Custodian;
import com.custodian_service.custodianService.model.Project;

import java.util.List;
import java.util.Optional;

public interface CustodianService {
     Custodian createCustodian(Custodian custodian);

     List<Custodian> findAllCustodians();

     Optional<Custodian> findById(Long id);

     void deleteById(Long id);

     Custodian updateCustodian(Long id, String newName);

     Custodian mergeCustodian(Long primary, Long duplicate);

     Project assignCustodians(List<Custodian> custodians, Project project);

     // API for GraphQL
   //  List<Custodian> findAllCustodiansUsingGraph();
}
