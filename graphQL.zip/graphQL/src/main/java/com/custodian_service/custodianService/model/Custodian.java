package com.custodian_service.custodianService.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

@Table(name="custodian")
public class Custodian {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public Custodian(String name, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.name = name;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    @ManyToOne
    @JoinColumn(name = "project_id")
    private Project project;

    private String name;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
