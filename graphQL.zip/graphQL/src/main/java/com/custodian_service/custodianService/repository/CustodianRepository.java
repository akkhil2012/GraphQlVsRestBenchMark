package com.custodian_service.custodianService.repository;

import com.custodian_service.custodianService.model.Custodian;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustodianRepository extends JpaRepository<Custodian,Long> {
}
