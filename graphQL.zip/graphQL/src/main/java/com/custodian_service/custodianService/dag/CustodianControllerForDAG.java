package com.custodian_service.custodianService.dag;

import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.ollama.*;
import org.springframework.ai.ollama.api.OllamaOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/v1/gad/custodian")
public class CustodianControllerForDAG {

    private final ChatModel chatModel;

    private DocumentRetriever retriever;
    private TextGenerator generator;

    public CustodianControllerForDAG(ChatModel chatModel) {
        this.chatModel = chatModel;
        this.retriever = new DocumentRetriever();
        this.generator = new TextGenerator();
    }

    // TO DO
   /* @GetMapping("/custodians/{query}")
    public String answerQuery(String query) {
        List<String> documents = retriever.retrieveDocuments(query);
        String context = String.join(" ", documents);
        String response = generator.generateResponse(context);
        System.out.println("response is -------> "+ response);
        return response;
    }*/

   @GetMapping("/ai/ollama/chat")
    public String generate(@RequestParam(value = "message") String message) {
        ChatResponse response = chatModel.call(
                new Prompt(
                        message,
                        OllamaOptions.create()
                                .withModel("llama3")
                                .withTemperature(0.4f)
                ));
        return response.getResult().getOutput().getContent();
    }

}
