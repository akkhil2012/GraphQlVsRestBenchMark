package com.custodian_service.custodianService.controller;

import com.custodian_service.custodianService.model.Custodian;
import com.custodian_service.custodianService.service.CustodianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v1/custodian")
public class CustodianController {

    @Autowired
    CustodianService custodianService;

    @PostMapping("/custodians")
    public ResponseEntity<Custodian> createCustodian(@RequestBody Custodian custodian){
        Custodian createdCustodian =  custodianService.createCustodian(custodian);
        System.out.println(" Custodian created...");
        return ResponseEntity.ok(createdCustodian);
    }

    @GetMapping("/custodians")
    public ResponseEntity<?> createCustodian(){
        List<Custodian> custodians =  custodianService.findAllCustodians();
        System.out.println(" Custodian created...");
        return ResponseEntity.ok(custodians);
    }

    @GetMapping("/custodians/{id}")
    public ResponseEntity<?> fetchCustodianById(@PathVariable("id") Long id){
        Optional<Custodian> custodian =  custodianService.findById(id);
        System.out.println(" Custodian fetched...");
        if(!custodian.isPresent())
            return ResponseEntity.ok("Custodian NOT Found");
         return ResponseEntity.ok(custodian);
    }

    @DeleteMapping("/custodians/{id}")
    public ResponseEntity<?> deleteCustodianById(@PathVariable("id") Long id){
        custodianService.deleteById(id);
       // System.out.println(" Custodian deleted...");
        return ResponseEntity.ok("CustodianDeleted...");
    }

   /* @PutMapping("/custodians/{id}")
    public ResponseEntity<?> updateCustodianById(@RequestBody Custodian custodian){
        custodianService.deleteById(id);
        // System.out.println(" Custodian deleted...");
        return ResponseEntity.ok("CustodianDeleted...");
    }*/
}
