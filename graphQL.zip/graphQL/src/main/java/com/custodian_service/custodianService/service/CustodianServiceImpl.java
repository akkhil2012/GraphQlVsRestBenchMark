package com.custodian_service.custodianService.service;

import com.custodian_service.custodianService.model.Custodian;
import com.custodian_service.custodianService.model.Project;
import com.custodian_service.custodianService.repository.CustodianRepository;
import com.custodian_service.custodianService.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustodianServiceImpl implements  CustodianService{

    @Autowired
    CustodianRepository custodianRepository;

    @Autowired
    ProjectRepository projectRepository;

    @Override
    public Custodian createCustodian(Custodian custodian) {
        return custodianRepository.save(custodian);
    }

    @Override
    public List<Custodian> findAllCustodians() {
        return custodianRepository.findAll();
    }

    @Override
    public Optional<Custodian> findById(Long id) {
        return custodianRepository.findById(id);
    }

    @Override
    public void deleteById(Long id) {
        custodianRepository.deleteById(id);
    }

    @Override
    public Custodian updateCustodian(Long id, String newName){

        Custodian existingProduct= custodianRepository.findById(id)
                .orElseThrow(()-> new RuntimeException("product not found with id "+id));

        existingProduct.setName(newName);
        return custodianRepository.save(existingProduct);
    }

    @Override
    public Custodian mergeCustodian(Long primary, Long duplicate) {
        Custodian existingPrimary= custodianRepository.findById(primary)
                .orElseThrow(()-> new RuntimeException("product not found with id "+primary));
        Custodian existingDuplicate= custodianRepository.findById(duplicate)
                .orElseThrow(()-> new RuntimeException("product not found with id "+duplicate));
        existingPrimary.setName(existingPrimary.getName()+existingDuplicate.getName());

        custodianRepository.deleteById(duplicate);
        custodianRepository.save(existingPrimary);
        return existingPrimary;
    }

    @Override
    public Project assignCustodians(List<Custodian> custodians, Project project) {
        return  projectRepository.save(project);
    }
}
