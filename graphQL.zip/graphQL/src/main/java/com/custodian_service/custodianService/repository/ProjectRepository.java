package com.custodian_service.custodianService.repository;

import com.custodian_service.custodianService.model.Custodian;
import com.custodian_service.custodianService.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ProjectRepository extends JpaRepository<Project,Long> {
}
